# Proyecto_Python_Galvis_Pamela
Una compañía de transportes y logística desea desarrollar un progra­ma en Python que permita llevar el registro y control de todos los envíos, recepción y reparto de Paquetes.  Para ello usted es contratado para liderar el desarrollo del programa que debe cumplir con las siguientes especificaciones:
